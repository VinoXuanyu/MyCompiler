package CodeGen;

public class Variable {
    public int index;
    public int dimensions = 0;
    public int firstDim;
    public int secondDim;

    public Variable(int index) {
        this.index = index;
    }
}
