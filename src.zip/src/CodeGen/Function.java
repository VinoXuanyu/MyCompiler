package CodeGen;

public class Function {
    public int index;
    public int argCount;

    public Function(int index, int argCount) {
        this.index = index;
        this.argCount = argCount;
    }
}
